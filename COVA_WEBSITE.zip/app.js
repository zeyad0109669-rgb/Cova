
let products = JSON.parse(localStorage.getItem("products")) || [];

function showProducts(){
    let box = document.getElementById("products");
    box.innerHTML = "";

    products.forEach((p,i)=>{
        box.innerHTML += `
        <div class="card">
            <img src="${p.img}">
            <h3>${p.name}</h3>
            <div class="price">
                ${p.oldPrice ? `<span class="old">${p.oldPrice}</span>` : ""}
                <span>${p.price} EGP</span>
            </div>
            <a class="btn" href="product.html?id=${i}">عرض المنتج</a>
        </div>
        `;
    });
}

showProducts();
