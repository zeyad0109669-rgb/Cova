import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { app } from "./firebase.js";

const db = getFirestore(app);

window.searchProducts = async function(){
let q = document.getElementById('search').value.toLowerCase();
let snap = await getDocs(collection(db,'products'));
let box = document.getElementById('products');
box.innerHTML='';

snap.forEach(doc=>{
let p = doc.data();
if(p.name.toLowerCase().includes(q)){
box.innerHTML += `
<div class='card'>
<img src='${p.img}'>
<h3>${p.name}</h3>
<b>${p.price}</b>
<a class='btn' href='https://wa.me/201096694034?text=Order:${p.name}'>Order</a>
</div>`;
}
});
}
